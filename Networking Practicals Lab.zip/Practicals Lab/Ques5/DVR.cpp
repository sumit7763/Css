#include <iostream>
#define infinity 21474836
using namespace std;

int main(){
    int n;
    cout<<"Enter number of Nodes: ";
    cin>>n; 
    int array[n][n];
    cout << "Enter costs (enter -1 for infinity):" << endl;
    for(int i=0; i<n; i++){
        for(int j= 0; j<=i; j++){
            if(i==j){
                array[i][j] = 0;
            }
            else{
                cout<<(char)(i + 65)<<" to "<<(char)(j + 65)<<" is: ";
                cin>>array[i][j];
            }
            if(array[i][j] == -1)
                array[i][j] = infinity;
            array[j][i] = array[i][j];
        }
    }
    for(int i=0; i<n; i++){
        cout<<"\t"<<(char)(i+ 65)<<" Table";
    }
    cout<<endl;
    for(int i=0; i<n; i++){
        cout<<(char)(i + 65)<<"\t";
        for(int j=0; j<n; j++){
            if(array[i][j] == infinity)
                cout<<"inf"<<"\t";
            else
                cout<<array[i][j]<<"\t";
        }
        cout<<endl;
    }
    cout<<endl;

    bool cond= true;
    while(cond){
        for(int i=0; i<n; i++){
            for(int j=0; j<n; j++){
                if(i==j && array[i][j]==infinity)
                    continue;
                for(int k=0; k<n; k++){
                    array[i][k]= min(array[i][k], array[i][j]+array[j][k]);
                }
            }
        }
        cond=false;
        for(int i=0; i<n; i++){
            for(int j=0; j<n; j++){
                if (array[i][j]==infinity)
                    cond = true;
            }
        }
    }

    cout<<"At time t2 "<<endl;
    for(int i = 0; i < n; i++){
        cout<<"\t"<<(char)(i + 65)<<" Table";
    }
    cout<<endl;
    for(int i=0; i<n; i++){
        cout<<(char)(i + 65)<<"\t";
        for(int j=0; j<n; j++){
            if(array[i][j]==infinity)
                cout<<"inf"<<"\t";
            else
                cout<<array[i][j]<<"\t";
        }
        cout<<endl;
    }
    return 0;
}